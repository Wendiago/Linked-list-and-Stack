#include <iostream>
#include "List.h"
using namespace std;

int main()
{
	List linkedList1;
	linkedList1.insert(0, "Phung Le Hoang Ngoc");
	linkedList1.insert(1, "Huynh Cao Khoi");
	linkedList1.insert(2, "Truong Anh Khoa");
	linkedList1.insert(3, "Tran Dinh Nhat");

	cout << "Xuat danh sach: " << endl;
	linkedList1.print();
	cout << endl;

	linkedList1.insert(2, "Pham Le Tu Nhi");
	cout << "Xuat danh sach: " << endl;
	linkedList1.print();
	cout << endl;

	linkedList1.erase(2);
	cout << "Xuat danh sach: " << endl;
	linkedList1.print();
	cout << endl;
	
	return 0;
}